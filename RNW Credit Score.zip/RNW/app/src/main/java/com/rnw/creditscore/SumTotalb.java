package com.rnw.creditscore;

import android.util.Log;

public final class SumTotalb {
    public static void a(StringBuilder sb, String str, String str2) {
        sb.append(str);
        Log.d(str2, sb.toString());
    }

    public static String a(String str, String str2) {
        return str + str2;
    }

    public static String a(String str, String str2, String str3) {
        return str + str2 + str3;
    }
}
